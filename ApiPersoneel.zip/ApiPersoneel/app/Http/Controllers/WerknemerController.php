<?php

namespace App\Http\Controllers;

use App\Models\Werknemer;
use Illuminate\Http\Request;

class WerknemerController extends Controller
{
    public function index()

    {

        return Werknemer::All();
    }

    public function store(Request $request)

    {

        return Werknemer::create($request->all());
    }

    public function show(Werknemer $werknemer)

    {

        return $werknemer;
    }

    public function update(Request $request, Werknemer $werknemer)

    {

        $werknemer->update($request->all());

        return $werknemer;
    }

    public function destroy(Werknemer $werknemer)

    {

        $werknemer->delete();
    }
}
